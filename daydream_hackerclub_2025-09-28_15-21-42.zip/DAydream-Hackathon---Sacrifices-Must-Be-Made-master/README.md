Created for the Daydream Game Jam - Sydney, 2025
The theme was Sacrifices Must Be Made
This is a Godot File for Version 4.5. It is not recommended to use an older version, though it will still run.
The code is open source and free to use. No attribution is needed.
Music was created in flat.io
Code was created in Godot
Credits:
Ethan S: Design, Playtesting, Composition, Brainstorming
Ethan H: Coding, Playtesting, Brainstorming
Orlando W: Debugging
